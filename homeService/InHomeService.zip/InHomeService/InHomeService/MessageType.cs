﻿namespace InHomeService
{
    /// <summary>
    /// The type of message this is.
    /// Request is a normal request
    /// Service is for internal use
    /// UserIdentification is used to let the network know who signed in
    /// </summary>
    public enum MessageType
    {
        Request,
        Service,
        UserIdentification
    }
}
