﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace InHomeService
{
    public partial class MainForm : Form
    {
        private delegate void ThreadGUIDelegate(Message message);

        private UdpClient udpClient = new UdpClient(17654);

        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.username == "notset")
            {
                if (MessageBox.Show("Warnung! Der Benutzer wurde noch nicht festgelegt!\nEs koennen aktuell keine Anfragen empfangen werden!\nSoll der Benutzer jetzt festgelegt werden?",
                    "Kein Benutzer!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    SettingsToolStripMenuItem_Click(null, new EventArgs());
                }
            }

            StartListening();
        }

        private void StartListening()
        {
            udpClient.BeginReceive(Recieve, new object());
        }

        private void AddItemThreadSafe(Message message)
        {
            if (listViewMessages.InvokeRequired)
            {
                ThreadGUIDelegate threadGUIDelegate = new ThreadGUIDelegate(AddItemThreadSafe);
                Invoke(threadGUIDelegate, new object[] { message });
            }
            else
            {
                listViewMessages.Items.Add(new ListViewItem(new string[] {
                    message.Reason,
                    message.Priority.ToString(),
                    message.Dispatched.ToString(),
                }));
            }
        }

        private void Recieve(IAsyncResult result)
        {
            try
            {
                /* Get the message from the network stream */
                IPEndPoint iPEndPoint = new IPEndPoint(IPAddress.Any, 17654);
                byte[] buffer = udpClient.EndReceive(result, ref iPEndPoint);

                string messageString = Encoding.ASCII.GetString(buffer);

                /* parse the protocol into a message */
                Message message = new Message();
                message.Parse(messageString);

                /* test if this is important to the user */
                if (message.Name == Properties.Settings.Default.username || message.Type == MessageType.UserIdentification)
                {
                    /* dispatch an alert if yes */
                    notifyIcon.ShowBalloonTip(2000);

                    AddItemThreadSafe(message);

                    using (AlertForm alertForm = new AlertForm())
                    {
                        alertForm.AlertReason = message.Reason;
                        alertForm.AlertPriority = message.Priority;

                        alertForm.ShowDialog();
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ein Fehler ist aufgetreten!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                /* and start over */
                StartListening();
            }
        }

        private void SettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SettingsForm settingsForm = new SettingsForm())
            {
                settingsForm.ShowDialog();
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            MinimizeToTray();
        }

        private void MinimizeToTray()
        {
            WindowState = FormWindowState.Minimized;
            notifyIcon.Visible = true;
            ShowInTaskbar = false;
        }

        private void OpenFromTray()
        {
            WindowState = FormWindowState.Normal;
            notifyIcon.Visible = false;
            ShowInTaskbar = true;
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                MinimizeToTray();
            }
        }

        private void NotifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            OpenFromTray();
        }
    }
}
