﻿using System;
using System.Windows.Forms;
using System.Media;
using System.Drawing;

namespace InHomeService
{
    public partial class AlertForm : Form
    {
        public string AlertReason
        {
            set
            {
                labelReason.Text = value;

                /* this will enable word wrap on the label */
                labelReason.AutoSize = false;
                labelReason.MaximumSize = new Size(ClientRectangle.Width - 50, 0);
                labelReason.AutoSize = true;
            }
        }

        public Priority AlertPriority
        {
            set
            {
                switch (value)
                {
                    case Priority.Low:
                        labelPriority.ForeColor = Color.Green;
                        break;
                    default:
                    case Priority.Normal:
                        labelPriority.ForeColor = Color.Blue;
                        break;
                    case Priority.High:
                        labelPriority.ForeColor = Color.Red;
                        break;
                }
                labelPriority.Text = value.ToString();
            }
        }

        public AlertForm()
        {
            InitializeComponent();
        }

        private void ButtonOkay_Click(object sender, EventArgs e)
        {
            /* Make sure the user really knows what he is about to do! */

            if (MessageBox.Show("Warnung! Durch das akzeptieren dieser Anfrage wird\ndie Verantwortung auf den User weitergegeben!",
                "Anfrage akzeptieren", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (MessageBox.Show("Die Anfrage wurde akzeptiert!\nDie Meldung wird nun geschlossen!\nBitte folge der Anfrage!",
                    "Anfrage akzeptieren", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) == DialogResult.OK)
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
        }

        private void AlertForm_Load(object sender, EventArgs e)
        {
            /* Play a sound to get the attention! */
            TriggerAlert();


            /* Play the sound every five seconds from now on! */
            timer.Start();

            /* center the labels */
            labelReason.Left = (labelReason.Parent.Width - labelReason.Width) / 2;
            labelPriority.Left = (labelPriority.Parent.Width - labelPriority.Width) / 2;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            TriggerAlert();
        }

        private void TriggerAlert()
        {
            using (SoundPlayer soundPlayer = new SoundPlayer(Properties.Resources.message))
            {
                soundPlayer.Play();
            }

            BringToFront();
        }
    }
}
