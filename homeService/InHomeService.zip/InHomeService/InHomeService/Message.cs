﻿using System;

namespace InHomeService
{
    internal class Message
    {
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _name;

        public string Reason
        {
            get { return _reason; }
            set { _reason = value; }
        }
        private string _reason;

        public Priority Priority
        {
            get { return _priority; }
            set { _priority = value; }
        }
        private Priority _priority;

        public DateTime Dispatched
        {
            get { return _dispatched; }
            set { _dispatched = value; }
        }
        private DateTime _dispatched;

        public MessageType Type
        {
            get { return _type; }
            set { _type = value; }
        }
        private MessageType _type;

        /// <summary>
        /// Parses a string into a message.
        /// </summary>
        /// <param name="messageString">The string to parse</param>
        /// <exception cref="FormatException">Is thrown if the string is not in the expected format</exception>
        public void Parse(string messageString)
        {
            /* Our protocol is pretty simple
             * [messageType],[recievant],[reason],[priority],[dispatchDate],[dispatchTime] 
             */
            string[] segments = messageString.Split(',');

            if (segments.Length != 6)
            {
                throw new FormatException($"'{messageString}' is not a valid Message!");
            }

            switch (segments[0])
            {
                default:
                case "Request":
                    _type = MessageType.Request;
                    break;
                case "Service":
                    _type = MessageType.Service;
                    break;
                case "UserIdentification":
                    _type = MessageType.UserIdentification;
                    break;
            }

            _name = segments[1];
            _reason = segments[2];

            switch (segments[3])
            {
                default:
                case "Normal":
                {
                    _priority = Priority.Normal;
                    break;
                }
                case "Low":
                {
                    _priority = Priority.Low;
                    break;
                }
                case "High":
                {
                    _priority = Priority.High;
                    break;
                }
            }

            if (!DateTime.TryParse($"{segments[4]} {segments[5]}", out _dispatched))
            {
                throw new FormatException($"'{segments[4]} {segments[5]}' is not a valid date and/or time!");
            }
        }

        public override string ToString()
        {
            /* Build a string that can be send through the network 
             * The string is formated according to the protocol. */
            return $"{_type},{_name},{_reason},{_priority},{_dispatched.ToShortDateString()},{_dispatched.ToShortTimeString()}";
        }
    }
}
