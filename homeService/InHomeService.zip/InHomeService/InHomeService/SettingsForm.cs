﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace InHomeService
{
    public partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
        }

        private void ButtonSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(comboBoxUser.SelectedItem.ToString()))
            {
                MessageBox.Show("Es muss ein Benutzer ausgewaehlt werden!", "Benutzername", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Properties.Settings.Default.username = comboBoxUser.SelectedItem.ToString();
                Properties.Settings.Default.Save();

                MessageBox.Show($"Jetzt angemeldet als Benutzer {Properties.Settings.Default.username}!", "Speichern erfolgreich!");

                SendUserChange();
            }
        }

        private void SendUserChange()
        {
            Message message = new Message()
            {
                Type = MessageType.UserIdentification,
                Name = $"@all",
                Reason = $"{Environment.MachineName}-{Environment.UserName} hat sich als {Properties.Settings.Default.username} angemeldet!",
                Priority = Priority.High,
                Dispatched = DateTime.Now
            };

            /* let everyone know that we are online
             * TODO: make server recieve this */
            using (UdpClient client = new UdpClient())
            {
                IPEndPoint iPEndPoint = new IPEndPoint(IPAddress.Broadcast, 17654);

                byte[] bytes = Encoding.ASCII.GetBytes(message.ToString());

                client.Send(bytes, bytes.Length, iPEndPoint);
            }
        }

        private void ButtonAutostart_Click(object sender, EventArgs e)
        {
            /* make an registry entry to autostart this tool */
            RegistryKey rk = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);

            rk.SetValue("InHomeService", Application.ExecutablePath);
        }

        private void SettingsForm_Load(object sender, EventArgs e)
        {
            /* this is kinda ugly, may improve at some time */

            if (Properties.Settings.Default.username != "notset")
            {
                for (int i = 0; i < comboBoxUser.Items.Count; i++)
                {
                    if (comboBoxUser.Items[i].ToString() == Properties.Settings.Default.username)
                    {
                        comboBoxUser.SelectedIndex = i;

                        break;
                    }
                }
            }
            else
            {
                comboBoxUser.SelectedIndex = 0;
            }
        }

        private void ButtonClose_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
