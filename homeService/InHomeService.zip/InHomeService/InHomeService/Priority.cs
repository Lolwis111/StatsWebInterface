﻿namespace InHomeService
{
    /// <summary>
    /// The priority of a message.
    /// </summary>
    public enum Priority
    {
        Low,
        Normal,
        High
    }
}
